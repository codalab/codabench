### How is the scoring metric computed?

The discriminating metric will be computed on the **A** matrix: **mean absolute error** between the estimate and the groundtruth.

The matrix **D** of shape (N patients, M probes) is provided.
**D = T A**, with **T** the cell-type profiles (k cell types, M variables) and **A** the cell-type proportion per patients (N patients, k cell types).

Participants have to identify an estimate of **A** matrix.

During this benchmark, they have to submit a reproductible script (with their implemented solution) that compute **A**. This script will be applied on 10 simulated data sets to estimate 10 **A** matrices, and the mean of the MAE between those estimations and the simulated **A** matrices will be used for scoring.
print("I'm scoring!")


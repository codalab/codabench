### Goal of the benchmark

**The goal of the benchmark** is to quantify tumor heterogeneity : how many cell types are present and in which proportion?

We assume **D** is a (MxN) methylome matrix composed of methylome value for N samples, at M probes. Each sample is constituted of **K** cell types. We assume the following model: **D = T A**

with **T** an unknown (MxK) matrix of **K** cell type-specific methylome reference profiles (composed of M sites), and **A** an unknown (KxN) proportion matrix composed of **K** cell type proportions for each sample.

> Participants have to identify an **estimate of A matrix**. Teams are invited to propose inovative methods using RNAseq approaches to estimate **A**.

```
D_matrix = readRDS(file = "public_data.rds")
```


- the methylome dataset is composed of `r ncol(x = D_matrix)` patients and `r nrow(x = D_matrix)` probes, with cell types proportions highly variable between patients.


print("Starting submission...")
with open('output/answer.txt', 'w') as output_file:
    output_file.write('3.141592653589793238462642')
print("..I wrote out pi, done!")

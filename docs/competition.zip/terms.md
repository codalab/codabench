# Terms and Conditions

We only have two rules

#### Rule number one
Don't cheat

#### Rule number two
See rule number one